package com.example;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

@Service
public class EmployeeService {
    private final Map<String, Employee> employeeMap = new HashMap<>();

    public Collection<Employee> getAllEmployees() {
        return employeeMap.values();
    }

    public Employee getEmployeeById(String id) {
        return employeeMap.get(id);
    }

    public Employee saveEmployee(Employee employee) {
        return employeeMap.put(employee.getId(), employee);
    }

    public Employee updateEmployee(String id, Employee employee) {
        if (employeeMap.containsKey(id)) {
            employee.setId(id);
            return employeeMap.put(id, employee);
        }
        return null;
    }

    public Employee deleteEmployee(String id) {
        return employeeMap.remove(id);
    }
}
