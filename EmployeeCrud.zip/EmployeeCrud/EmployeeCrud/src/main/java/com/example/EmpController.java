package com.example;

import com.example.Employee;
import com.example.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Collection;

@RestController
@RequestMapping("/employees")
public class EmpController {
	@Autowired
	private EmployeeService employeeService;

	@GetMapping
	public Collection<Employee> getAllEmployees() {
		return employeeService.getAllEmployees();
	}

	@GetMapping("/{id}")
	public ResponseEntity<Employee> getEmployeeById(@PathVariable String id) {
		Employee employee = employeeService.getEmployeeById(id);
		if (employee != null) {
			return ResponseEntity.ok(employee);
		}
		return ResponseEntity.notFound().build();
	}

	@PostMapping
	public ResponseEntity<Employee> saveEmployee(@RequestBody Employee employee) {
		Employee savedEmployee = employeeService.saveEmployee(employee);
		return ResponseEntity.ok(savedEmployee);
	}

	@PutMapping("/{id}")
	public ResponseEntity<Employee> updateEmployee(@PathVariable String id, @RequestBody Employee employee) {
		Employee updatedEmployee = employeeService.updateEmployee(id, employee);
		if (updatedEmployee != null) {
			return ResponseEntity.ok(updatedEmployee);
		}
		return ResponseEntity.notFound().build();
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteEmployee(@PathVariable String id) {
		Employee deletedEmployee = employeeService.deleteEmployee(id);
		if (deletedEmployee != null) {
			return ResponseEntity.ok().build();
		}
		return ResponseEntity.notFound().build();
	}
}









//package com.example;
//
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//@RestController
//public class EmpController {
//    @RequestMapping("/bankname")
//    public String bankname(){
//        return "United Bank Of India";
//    }
//    
//    @RequestMapping("/bankAdd")
//    public String bankAdd(){
//        return "Onda MainRoad, Onda, Bankura, West Bengal, 722144";
//    }
//}